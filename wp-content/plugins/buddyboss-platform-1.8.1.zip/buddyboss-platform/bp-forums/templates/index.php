<?php

/**
 * Do not put custom themes here. They will be deleted on Forums updates.
 *
 * Keep custom Forums themes in /wp-content/themes/
 */
