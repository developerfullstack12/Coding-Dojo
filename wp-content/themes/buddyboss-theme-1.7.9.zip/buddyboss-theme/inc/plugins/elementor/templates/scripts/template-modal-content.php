<?php
/**
 * Templates Loader View.
 */
?>
<div class="bbelementor-filters-list"></div>
<div class="bbelementor-templates-wrap">
    <div id="elementor-template-library-filter-text-wrapper"></div>
    <div class="bbelementor-templates-list"></div>
</div>