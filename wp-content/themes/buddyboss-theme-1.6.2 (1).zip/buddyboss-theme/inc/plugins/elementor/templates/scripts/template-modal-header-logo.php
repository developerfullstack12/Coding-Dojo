<?php
/**
 * Template Library Modal Header
 */
?>
<span class="bbelementor-template-modal-header-logo-icon">
</span>
<span class="bbelementor-template-modal-header-logo-label">
    <?php echo __( 'BuddyBoss Elementor Sections', 'buddyboss-theme' ); ?>
</span>

