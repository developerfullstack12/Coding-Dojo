<?php
/**
 * Template Insert Button
 */
?>
<button class="elementor-template-library-template-action bbelementor-template-insert elementor-button elementor-button-success">
    <i class="eicon-file-download"></i><span class="elementor-button-title"><?php
		echo __( 'Insert', 'buddyboss-theme' );
		?></span>
</button>