<?php
/* template name:edit-Profile */
get_header(); 
if ( is_user_logged_in() ) {
    
  global $bp, $wpdb;

    $user_id = get_current_user_id();
    
    if(isset($_POST['usrup'])) {
     wp_update_user( array ('ID' => $user_id, 'display_name' => $_POST['display_name']));
     //xprofile_set_field_data( '4', $user_id, $_POST['dob'], $is_required = false );
     
     xprofile_set_field_data( '4', $user_id, $_POST['dob'], $is_required = false );
     xprofile_set_field_data( '5', $user_id, $_POST['sec_name'], $is_required = false );
     xprofile_set_field_data( '6', $user_id, $_POST['sec_email'], $is_required = false );
     xprofile_set_field_data( '7', $user_id, $_POST['sec_phone'], $is_required = false );
     xprofile_set_field_data( '8', $user_id, $_POST['rel_stu'], $is_required = false );

    if ( isset( $_FILES['userProfileImage'] ) ) {
      $file_name = $_FILES['userProfileImage']['name'];
      $image_full;
        $file = $_FILES['userProfileImage'];
        $file_path = $file['tmp_name'];
        $file_meta = getimagesize($file_path);
        // print_r($file_meta);

        if($file_meta !== false){
            // echo $upload_dir['basedir'];
            
            $uploads = wp_upload_dir();
            $upload_path = $uploads['basedir'];
            $folderpath = $upload_path."/avatars/".$user_id;
            if (!file_exists($folderpath)) {
                 mkdir($folderpath, 0777, true);
            } 
          // if($file_meta[0] == $file_meta[1]){
            $full_filename  = 'avatar-bpfull.'  . $FILE_EXTENSION;
            $thumb_filename = 'avatar-bpthumb.' . $FILE_EXTENSION;
            $target_dir = wp_get_upload_dir()['basedir'].'/avatars/'.$user_id.'/';

            $source = imagecreatefromstring(file_get_contents($file_path)); // La photo est la source

            $full = imagecreatetruecolor(150, 150);
            $thumb = imagecreatetruecolor(80, 80);

            imagecopyresampled($full, $source, 0, 0, 0, 0, imagesx($full), imagesy($full), imagesx($source), imagesy($source));
            imagecopyresampled($thumb, $source, 0, 0, 0, 0, imagesx($thumb), imagesy($thumb), imagesx($source), imagesy($source));

            if(imagejpeg($thumb, $target_dir.$thumb_filename.'jpeg') && imagejpeg($full, $target_dir.$full_filename.'jpeg')){
              // echo  "The file has been uploaded.";
            } 
            else {
              echo "Sorry, there was an error uploading your file.";
            }
          // }else{
          //   echo 'not a squared image';
          // }
        }
        // else{
        //   echo 'not an image';
        // }
    }
      // die;
     $url = site_url('profile');
     wp_redirect( $url );
     // echo "<script type='text/javascript'>window.location.href='". $url ."'</script>";  
    }

 if ( have_posts() ) : while ( have_posts() ) : the_post();
the_content();
endwhile; else: ?>
<p></p>
<?php endif; 

  $dob =  xprofile_get_field_data( '4', $user_id);
  $sec_contact_name =  xprofile_get_field_data( '5', $user_id);
  $sec_contact_realtion =  xprofile_get_field_data( '8', $user_id);
  function xprofile_dataget($field_id, $user_id)
    { 
        global $wpdb;
        $query = "SELECT value FROM `wp_bp_xprofile_data` WHERE field_id='".$field_id."' AND user_id='".$user_id."'";
        $chp = $wpdb->get_results($query);
        return $chp[0]->value;
    }
  $sec_contact_email =  xprofile_dataget( '6', $user_id);
  $sec_contact_phone =  xprofile_dataget( '7', $user_id);

?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<div class="container rounded bg-white mt-5 mb-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="text-right">Personal Details</h4>
    </div>
    <form method="post" id="edituser" action="<?php the_permalink(); ?>" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-6">
            <div class="">
                <div class="row mt-2">
                    <div class="col-md-4">
                        <label class="labels">Display Picture</label>
                        <?php echo get_avatar( get_current_user_id(), 100 ); ?>

 
                        <!--<img  width="100" height="100" src="https://bootdey.com/img/Content/avatar/avatar7.png" class="avatar img-circle img-thumbnail" alt="avatar">-->
                    </div>
                    <div class="col-md-6 cus_img"><input type="file" id="upload" name="userProfileImage" hidden/>
                        <label for="upload" id="c_upload">Upload Image</label>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-12"><label class="labels">Display Name</label><input type="text" name="display_name" class="form-control" placeholder="" value="<?php echo $current_user->display_name; ?>" required></div>
                    <div class="col-md-12"><label class="labels">Your Birthday</label><input type="text" id="datepicker" name="dob" class="form-control" placeholder="" value="<?php if(!empty($dob)){ echo $dob; }?>"></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="">
                <div class="row mt-3">
                    <div class="col-md-12"><label class="labels">Secondary Contact's Full Name</label><input type="text" name="sec_name" class="form-control" placeholder="" value="<?php if(!empty($sec_contact_name)){ echo $sec_contact_name; }?>"></div>
                    <div class="col-md-12"><label class="labels">Secondary Contact Email</label><input type="email" name="sec_email" class="form-control" value="<?php if(!empty($sec_contact_email)){ echo esc_html__($sec_contact_email); }?>"></div>
                    <div class="col-md-12"><label class="labels">Secondary Contact Number</label><input type="tel" name="sec_phone" class="form-control" placeholder="" value="<?php if(!empty($sec_contact_phone)){ echo esc_html__($sec_contact_phone); }?>"></div>
                    <div class="col-md-12"><label class="labels">Relationship to Student</label><input type="text" name="rel_stu" class="form-control" placeholder="" value="<?php if(!empty($sec_contact_realtion)){ echo $sec_contact_realtion; }?>"></div>
                </div>
            </div>
        </div>
        <div class="col-md-10">
            <!-- <div class="mt-5 text-center"><button class="btn btn-primary profile-button" type="button">Update</button></div> -->
             <input type="submit" id="sub" name="usrup" class="profile-button" value="Update »">
        </div>
    </div>
   </form>

    <br/><br/><br/>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="text-right">Purchase a Pass</h4>
    </div>

     <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="text-left">Number of Months left:</h5> &nbsp; &nbsp; &nbsp; &nbsp;
        <h6 class="text-center">
            <?php 
            $user = get_userdata($user_id);          
            $membership_level = pmpro_getMembershipLevelForUser($user_id);
            
            if(!empty($membership_level->expiration_number) )
            {            
             $expiration_date = $membership_level->enddate;
            
            //calculate days left
            $todays_date = current_time('timestamp');
            $time_left = $expiration_date - $todays_date;
            
            //time left?
            if($time_left > 0)
            {
                //convert to days and add to the expiration date (assumes expiration was 1 year)
                 $days_left = floor($time_left/(60*60*24));
                //figure out days based on period
                // if($membership_level->expiration_period == "Day")
                //     echo 'Day'.$total_days = $days_left + $membership_level->expiration_number;
                // elseif($membership_level->expiration_period == "Week")
                //     echo 'Week'.$total_days = $days_left + $membership_level->expiration_number * 7;
                // elseif($membership_level->expiration_period == "Month")
                //     echo 'Month'.$total_days = $days_left + $membership_level->expiration_number * 30;
                // elseif($membership_level->expiration_period == "Year")
                //     echo 'Year'.$total_days = $days_left + $membership_level->expiration_number * 365;

                // $years = floor(abs($time_left) / (365*60*60*24));
                $months = floor(($time_left - $years * 365*60*60*24) / (30*60*60*24));
                // $days = floor(($time_left - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                echo $months;
                //update the end date
                // echo date("Y-m-d", strtotime("+ $total_days Days", $todays_date));
              }
            }
            else
            {
                echo '0';
            }
            ?>
        </h6>
        &nbsp; &nbsp; &nbsp; &nbsp;<h6 class="text-right1">You will need purchase a pass to view lessons</h6>
     </div>
    <div class="row">
        <div class="col-md-12">
            <div class="">
                <div class="row mt-2">
                    <div class="col-md-3 ">
                        <h5 class="text-left" style="padding-top: 30px;">Purchase new passes</h5>
                    </div>
                    <?php
                    global $wpdb, $pmpro_msg, $pmpro_msgt, $pmpro_levels, $current_user, $pmpro_currency_symbol;
                    // print_r($pmpro_levels);
                    foreach($pmpro_levels as $level)
                    {
                    ?>
                    <div class="col-md-3 c_btn">
                       <input type="radio" class="getlevel" id="<?php echo $level->id; ?>" name="getlevelurl" value="<?php echo site_url().'/membership-account/membership-checkout/?level='.$level->id; ?>" />
                       <label for="<?php echo $level->id; ?>" class="memmber_label"><?php echo $level->name; ?><br/>
                        <span class="c_price">SGD <?php echo pmpro_formatPrice($level->initial_payment); ?></span></label>
                    </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="col-md-12 Purchase_btn">
            <div class="">
                <div class="row mt-2">
                    <div class="col-md-12 c_btn1">
                        <a href="" class="c_purchse_btn" id="geturl">Purchase</a>
                    </div>
                </div>
            </div>
            <div class="">
                <h6 class="text-right2">You will be redirect to stripe to make payment</h6>
            </div>
        </div>
        <div class="col-md-12">
            <div class="">
                <h4 class="text-left">Email Notification</h4>
                <br/>
                <div class="row mt-2">
                    <div class="col-md-8">
                        <h6 class="text-left">I would like to recieve weekly summary emails:</h6>
                    </div>
                    <div class="col-md-4 c_btn">
                        <button type="button"  class="btn_yes">Yes</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <button type="button" class="btn_no">No</button>
                    </div>
                </div>
            </div>
            <br/><br/>
            <h4 class="text-left">Payments Records</h4>
          
                <?php
                   $invoices = $wpdb->get_results("SELECT mo.*, UNIX_TIMESTAMP(mo.timestamp) as timestamp, du.code_id as code_id FROM $wpdb->pmpro_membership_orders mo LEFT JOIN $wpdb->pmpro_discount_codes_uses du ON mo.id = du.order_id WHERE mo.user_id = '$user_id' ORDER BY mo.timestamp DESC"); 

                  // $levelshistory = $wpdb->get_results("SELECT * FROM $wpdb->pmpro_memberships_users WHERE user_id = '$user_id' ORDER BY id DESC");
                ?>
                <?php if ( $invoices ) { ?>
                 <table>
                 <tr class="tab_heading_profile">
                    <th>Date</th>
                    <th>ID</th>
                    <th>No. of Pass</th>
                    <th>Amount</th>
                </tr>
                <?php
                    foreach ( $invoices as $invoice ) { 
                        $level = pmpro_getLevel( $invoice->membership_id );
                        ?>
                    <tr class="tab_con_profile">
                        <td><?php echo date_i18n( get_option( 'date_format'), $invoice->timestamp ); ?></td>
                        <td><?php echo $invoice->code; ?></td>
                        <td><?php if ( ! empty( $level ) ) { echo $level->name; } else { _e( 'N/A', 'pmpro-member-history'); } ?></td>
                        <td><?php echo pmpro_formatPrice( $invoice->total ); ?></td>
                    </tr>
               <?php } ?>
            </table>            
             <?php } else { 
                    esc_html_e( 'No membership history found.', 'pmpro-member-history');
                } ?>
               
        </div>
    </div>
</div>


  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
  <script src="https://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
  <script>
  $(function() {
    $("#datepicker").datepicker();

    
  });
  </script>


 <?php
}
else
{
     $urls = site_url();
     echo "<script type='text/javascript'>window.location.href='". $urls ."'</script>";  
}
?>

<style>
input[type="radio"] {
  display:none;
}
input[type="radio"]:checked + label {
  background: #6e6e6eeb;
  color: #fff;
}
</style>
<script type="text/javascript">
    jQuery(document).ready(function() {
    jQuery('.getlevel').click(function() {
        var value = jQuery("input[type=radio][name=getlevelurl]:checked").val();
        if (value) {
            jQuery('#geturl').attr("href", value)
        }
        else {
            alert('Nothing is selected');
        }
    })
});
</script>
<?php get_footer(); ?>